## EMPLOYEE MANAGEMENT SYSTEM

# ABOUT

A mini project made for companies to get the management of employees easy and more precise without any unwanted errors. Here is the solution for non-technical managers to get a good tool which keeps a track of all employees working in their organization, Except for employers and managers, college students can use this mini project as well to show case their skills and take reference from here.

The tech stack used here is:
* ASP.NET core
  *  ASP.NET is an open source web framework, created by Microsoft, for building modern web apps and services that run on macOS, Linux, Windows, and Docker.
* SQL DB
  * SQL database or relational database is a collection of highly structured tables, wherein each row reflects a data entity, and every column defines a specific information field. Relational databases are built using the structured query language (SQL) to create, store, update, and retrieve data.

# KEY TOPICS

* ADD
* SEARCH
* UPDATE
* DELETE
* LOGIN
* CREATE ACCOUNT

